# TMS VPN — Android client

TMS VPN is an Android application built with Kotlin and Jetpack Compose. The current project contains account sign-in, per-user Firestore data paths, configuration parsing, TCP reachability checks, and the existing management UI.

## Private configuration model

Each signed-in Firebase UID owns its own Firestore namespace:

- `users/{uid}/vpn_configs`
- `users/{uid}/vpn_servers`
- `users/{uid}/failover_policies`
- `users/{uid}/audit_logs`

The Firestore rules deny cross-user reads and writes. A client-created account receives only the `user` role. Elevated roles, subscription state, device quotas, and data limits must be assigned by a trusted backend using the Firebase Admin SDK / custom claims; the Android client is not allowed to grant itself administrator privileges.

**Important:** VPN configuration URIs contain credentials. Do not publish them, place them in public collections, include them in analytics, or print them to logs. Firestore owner rules isolate each account, but project administrators with privileged backend access can still access stored records. For stronger end-to-end privacy, add client-side envelope encryption with a user-controlled recovery mechanism before enabling cross-device sync.

## Current implementation status

Implemented in this source tree:

- Firebase Authentication integration (Google sign-in UI)
- User-scoped Firestore repository and real-time observation
- URI parsing for VLESS, VMess, Trojan, and Shadowsocks formats
- TCP socket reachability timing (not a full VPN handshake or end-to-end latency test)
- Existing Compose management screens
- Firestore rules for per-user isolation and protected role/quota fields

Not yet implemented / not yet verified:

- A production VPN tunnel service (`VpnService`) connected to a supported proxy core
- A bundled and verified sing-box/libbox Android runtime
- End-to-end traffic routing, DNS routing, IPv6 handling, kill switch, and reconnect behavior
- Real throughput tests and long-duration stability scoring
- A deployed central API/VPS and trusted backend role provisioning
- A verified APK build and device test

The UI must not report a VPN as connected until the tunnel core confirms that the TUN interface is established and traffic is actually routed. TCP reachability alone is not proof that a proxy configuration works.

## Next engineering milestone

Integrate a pinned, license-compliant sing-box Android core build (AAR/native ABI artifacts) behind a small engine interface. Then implement the Android `VpnService` lifecycle, permission consent, foreground notification, start/stop/error states, and tests on a real device. The native core artifact must be built and checked for every supported ABI; a Gradle dependency declaration alone is not a working VPN engine.

## Firebase setup

1. Add the Firebase Android configuration file for the correct Firebase project.
2. Enable the chosen Firebase Authentication provider.
3. Deploy `firestore.rules`.
4. Run the Firestore emulator tests in `firestore.test.js` before deploying rule changes.
5. Provision any administrator role from a trusted server only; never hard-code admin UIDs or secrets into the APK.

Do not commit `.env`, service-account JSON files, signing keys, or private VPN configuration URIs.
